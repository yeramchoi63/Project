package com.kosta.simli.dto;

public class ScheduleDTO {
	
	private String employeeid;
	private int mon_s,mon_e,thu_s,thu_e,wed_s,wed_e,thr_s,thr_e,fri_s,fri_e,sat_s,sat_e;
	
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public int getMon_s() {
		return mon_s;
	}
	public void setMon_s(int mon_s) {
		this.mon_s = mon_s;
	}
	public int getMon_e() {
		return mon_e;
	}
	public void setMon_e(int mon_e) {
		this.mon_e = mon_e;
	}
	public int getThu_s() {
		return thu_s;
	}
	public void setThu_s(int thu_s) {
		this.thu_s = thu_s;
	}
	public int getThu_e() {
		return thu_e;
	}
	public void setThu_e(int thu_e) {
		this.thu_e = thu_e;
	}
	public int getWed_s() {
		return wed_s;
	}
	public void setWed_s(int wed_s) {
		this.wed_s = wed_s;
	}
	public int getWed_e() {
		return wed_e;
	}
	public void setWed_e(int wed_e) {
		this.wed_e = wed_e;
	}
	public int getThr_s() {
		return thr_s;
	}
	public void setThr_s(int thr_s) {
		this.thr_s = thr_s;
	}
	public int getThr_e() {
		return thr_e;
	}
	public void setThr_e(int thr_e) {
		this.thr_e = thr_e;
	}
	public int getFri_s() {
		return fri_s;
	}
	public void setFri_s(int fri_s) {
		this.fri_s = fri_s;
	}
	public int getFri_e() {
		return fri_e;
	}
	public void setFri_e(int fri_e) {
		this.fri_e = fri_e;
	}
	public int getSat_s() {
		return sat_s;
	}
	public void setSat_s(int sat_s) {
		this.sat_s = sat_s;
	}
	public int getSat_e() {
		return sat_e;
	}
	public void setSat_e(int sat_e) {
		this.sat_e = sat_e;
	}
	
	public ScheduleDTO() {

	}
	
	public ScheduleDTO(String employeeid, int mon_s, int mon_e, int thu_s, int thu_e, int wed_s, int wed_e, int thr_s,
			int thr_e, int fri_s, int fri_e, int sat_s, int sat_e) {
		super();
		this.employeeid = employeeid;
		this.mon_s = mon_s;
		this.mon_e = mon_e;
		this.thu_s = thu_s;
		this.thu_e = thu_e;
		this.wed_s = wed_s;
		this.wed_e = wed_e;
		this.thr_s = thr_s;
		this.thr_e = thr_e;
		this.fri_s = fri_s;
		this.fri_e = fri_e;
		this.sat_s = sat_s;
		this.sat_e = sat_e;
	}

}
