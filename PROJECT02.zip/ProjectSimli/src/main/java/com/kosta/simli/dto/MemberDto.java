package com.kosta.simli.dto;

import java.sql.Timestamp;

public class MemberDto {

	private String id, pwd, name, email, phone, gender, birth, addr, therapy1, therapy2, therapy3, part;
	private Timestamp mem_date;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getTherapy1() {
		return therapy1;
	}
	public void setTherapy1(String therapy1) {
		this.therapy1 = therapy1;
	}
	public String getTherapy2() {
		return therapy2;
	}
	public void setTherapy2(String therapy2) {
		this.therapy2 = therapy2;
	}
	public String getTherapy3() {
		return therapy3;
	}
	public void setTherapy3(String therapy3) {
		this.therapy3 = therapy3;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public Timestamp getMem_date() {
		return mem_date;
	}
	public void setMem_date(Timestamp mem_date) {
		this.mem_date = mem_date;
	}
	
}
