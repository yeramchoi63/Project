package com.kosta.simli.controller;



import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;







@Controller
public class FaqController {

	@RequestMapping("/faqView")
	public String faqView(){
		return "board.faq_mark.faq";
	}
	
	@RequestMapping("/ajax_faqView")
	public String ajaxfaqView(){
		return "ajax.board.faq_mark.faq";
	}
}
	
