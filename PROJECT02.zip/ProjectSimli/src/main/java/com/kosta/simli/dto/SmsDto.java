package com.kosta.simli.dto;

import java.util.Date;

public class SmsDto {

	private String fromid, smstitle, smscon, toid;
	private Date smstime;
	private int num;
	
	public String getFromid() {
		return fromid;
	}
	public void setFromid(String fromid) {
		this.fromid = fromid;
	}
	public String getSmstitle() {
		return smstitle;
	}
	public void setSmstitle(String smstitle) {
		this.smstitle = smstitle;
	}
	public String getSmscon() {
		return smscon;
	}
	public void setSmscon(String smscon) {
		this.smscon = smscon;
	}
	public String getToid() {
		return toid;
	}
	public void setToid(String toid) {
		this.toid = toid;
	}
	public Date getSmstime() {
		return smstime;
	}
	public void setSmstime(Date smstime) {
		this.smstime = smstime;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public SmsDto(String fromid, String smstitle, String smscon, String toid, Date smstime, int num) {
		super();
		this.fromid = fromid;
		this.smstitle = smstitle;
		this.smscon = smscon;
		this.toid = toid;
		this.smstime = smstime;
		this.num = num;
	}
	
	public SmsDto() {}

	
}
