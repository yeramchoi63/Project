package com.kosta.simli.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class InspectController {

	@RequestMapping("/total_inspect")
	public String total_inspect() {
		
		return "board.inspect.total_inspect";
	}
	
	@RequestMapping("/character_inspect")
	public String character_inspect() {
		
		return "board.inspect.character_inspect";
	}
	
	@RequestMapping("/study_inspect")
	public String study_inspect() {
		
		return "board.inspect.study_inspect";
	}
	
	@RequestMapping("/play_inspect")
	public String play_inspect () {
		
		return "board.inspect.play_inspect";
	}
	
	@RequestMapping("/baby_inspect")
	public String baby_inspect () {
		
		return "board.inspect.baby_inspect";
	}
	
	@RequestMapping("/concentration_inspect")
	public String concentration_inspect() {
		
		return "board.inspect.concentration_inspect";
	}
	
	@RequestMapping("/selftest_inspect")
	public String selftest_inspect() {
		
		return "board.inspect.selftest_inspect";
	}
	
	/*ajax*/
	@RequestMapping("/ajax_total_inspect")
	public String ajaxtotal_inspect() {
		
		return "ajax.board.inspect.total_inspect";
	}
	
	@RequestMapping("/ajax_character_inspect")
	public String ajaxcharacter_inspect() {
		
		return "ajax.board.inspect.character_inspect";
	}
	
	@RequestMapping("/ajax_study_inspect")
	public String ajaxstudy_inspect() {
		
		return "ajax.board.inspect.study_inspect";
	}
	
	@RequestMapping("/ajax_play_inspect")
	public String ajaxplay_inspect () {
		
		return "ajax.board.inspect.play_inspect";
	}
	
	@RequestMapping("/ajax_baby_inspect")
	public String ajaxbaby_inspect () {
		
		return "ajax.board.inspect.baby_inspect";
	}
	
	@RequestMapping("/ajax_concentration_inspect")
	public String ajaxconcentration_inspect() {
		
		return "ajax.board.inspect.concentration_inspect";
	}
	
	@RequestMapping("/ajax_selftest_inspect")
	public String ajaxselftest_inspect() {
		
		return "ajax.board.inspect.selftest_inspect";
	}
	
	
}
