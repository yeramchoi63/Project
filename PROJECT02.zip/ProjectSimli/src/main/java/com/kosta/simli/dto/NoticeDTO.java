package com.kosta.simli.dto;

import java.sql.Timestamp;

public class NoticeDTO {
	
	private int noNum;
	private String noTitle, noContent, noName;
	private Timestamp  noDate;
	
	
	public int getNoNum() {
		return noNum;
	}
	public void setNoNum(int noNum) {
		this.noNum = noNum;
	}
	public String getNoTitle() {
		return noTitle;
	}
	public void setNoTitle(String noTitle) {
		this.noTitle = noTitle;
	}
	public String getNoContent() {
		return noContent;
	}
	public void setNoContent(String noContent) {
		this.noContent = noContent;
	}
	public String getNoName() {
		return noName;
	}
	public void setNoName(String noName) {
		this.noName = noName;
	}
	public Timestamp getNoDate() {
		return noDate;
	}
	public void setNoDate(Timestamp noDate) {
		this.noDate = noDate;
	}

	public NoticeDTO() {
		
	}
	
	
	public NoticeDTO(int noNum, String noTitle, String noContent, String noName, Timestamp noDate) {
		super();
		this.noNum = noNum;
		this.noTitle = noTitle;
		this.noContent = noContent;
		this.noName = noName;
		this.noDate = noDate;
	}
	
	 
   
}
