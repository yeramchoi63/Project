package com.kosta.simli.dao;

import java.util.List;

import com.kosta.simli.dto.ExemDto;

public interface ExemDao {
	public List<ExemDto> exemlist();	
}
